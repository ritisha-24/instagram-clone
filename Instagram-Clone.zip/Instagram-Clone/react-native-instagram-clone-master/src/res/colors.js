const colors = {
  background: '#000',
  bottomBackGround: '#121212',
  text: 'white',
  textFaded2: '#999',
  textInputBackground: '#262626',
  seperatorLineColor: '#1c1c1c',
  loginInputBackground: '#121212',
};

export default colors;
