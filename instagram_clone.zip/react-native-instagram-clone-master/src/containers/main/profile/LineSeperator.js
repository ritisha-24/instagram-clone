import React from 'react';
import {View} from 'react-native';

export default function LineSeperator() {
  return (
    <View
      style={{
        backgroundColor: '#262626',
        height: 1,
        justifyContent: 'center',
        marginTop: 10,
      }}></View>
  );
}
